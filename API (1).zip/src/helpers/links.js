const links={
ImageUrl:'https://www.ivneu.com/ivneuUploadsDir/'
}
module.exports=links;