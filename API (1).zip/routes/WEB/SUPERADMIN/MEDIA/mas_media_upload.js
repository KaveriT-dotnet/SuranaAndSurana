module.exports = function(router, db){ 
//*******************************API - GET***********************************************************//
router.get('/get_mas_media_upload',(req,res)=>{
 var query =  " select * from mas_media_upload  where active_flag=1 "; 
 db.query(query,function(err,response){  
 if(err){     
 console.log(err);  
  res.send({ status: 0, msg: 'Failed', data: err }); 
 }else{   
  res.send({ status: 1, msg: 'Success', data: response }); 
  }  
  });  
}); 
//*******************************API - POST***********************************************************//
router.post('/insert_mas_media_upload',(req,res)=>{
var reqParams = req.body;
var query =  " INSERT INTO mas_media_upload ( height,width,size,resolution,max_image,max_active_image,Image_or_Video_type,active_flag,created_by,created_on,modified_by,modified_on ) values ( '" +reqParams.height +"' ,'" +reqParams.width +"' ,'" +reqParams.size +"' ,'" +reqParams.resolution +"' ,'" +reqParams.max_image +"' ,'" +reqParams.max_active_image +"' ,'" +reqParams.Image_or_Video_type +"' ,'" +reqParams.active_flag +"' ,'" +reqParams.created_by +"' ,'" +reqParams.created_on +"' ,'" +reqParams.modified_by +"' ,'" +reqParams.modified_on +"' ) "; 
 db.query(query,function(err,response){  
 if(err){     
 console.log(err);  
  res.send({ status: 0, msg: 'Failed', data: err }); 
 }else{   
  res.send({ status: 1, msg: 'Success', data: response }); 
  }  
  });  
}); 
// *******************************API - Edit***********************************************************//
router.put('/edit_mas_media_upload',(req,res)=>{
var reqParams = req.body;
var query =  " update mas_media_upload set height =  '"+reqParams.height +"',width =  '"+reqParams.width +"',size =  '"+reqParams.size +"',resolution =  '"+reqParams.resolution +"',max_image =  '"+reqParams.max_image +"',max_active_image =  '"+reqParams.max_active_image +"',Image_or_Video_type =  '"+reqParams.Image_or_Video_type +"',active_flag =  '"+reqParams.active_flag +"',created_by =  '"+reqParams.created_by +"',created_on =  '"+reqParams.created_on +"',modified_by =  '"+reqParams.modified_by +"',modified_on =  '"+reqParams.modified_on +"' Where  id = '"+reqParams.id+ "' " ; 
 db.query(query,function(err,response){  
 if(err){     
 console.log(err);  
  res.send({ status: 0, msg: 'Failed', data: err }); 
 }else{   
  res.send({ status: 1, msg: 'Success', data: response }); 
  }  
  });  
})
//*******************************API - Delete***********************************************************//
router.delete('/deletemas_media_upload',(req,res)=>{
var reqParams = req.body;
var query =  " update mas_media_upload set active_flag=0 Where  id = '"+reqParams.id+ "' " ; 
 db.query(query,function(err,response){  
 if(err){     
 console.log(err);  
  res.send({ status: 0, msg: 'Failed', data: err }); 
 }else{   
  res.send({ status: 1, msg: 'Success', data: response }); 
  }  
  });  
})
return router; }    
