var query,reqParams;
module.exports=function (router,db)
{
  
//*******************************API - Select***********************************************************//
router.get('/getSpeciality',(req,res)=>{
     query="";  
     //query="select * from getSpeciality";
     query="SELECT id,speciality FROM `mas_doctor_speciality` where active_flag=1";
    db.query(query,(err,data)=>{
    if(err) 
    {      console.log({error:err.error})   }
   else   
    {       res.send({status:1,msg:"Success",data:data})     }
    }    	)

  });
  //*******************************API - Insert***********************************************************//
  router.post('/insertSpeciality',(req,res)=>{
    
     query=""; 
     reqParams="";
     reqParams=req.body;
     //query="select * from getSpeciality";

     query="INSERT INTO `mas_doctor_speciality` ( `speciality`, `created_by`, `created_on` )  VALUES ('"+reqParams.speciality+"','"+reqParams.created_by+"',CURDATE())";
     
     //query="select 'success' as output";
    db.query(query,(err,data)=>{
    if(err) 
    {      console.log({error:err})   }
   else   
    {       res.send({status:1,msg:"Success",data:data})     }
    }    	) 

  }); 

//*******************************API - Update***********************************************************//


//*******************************API - Delete***********************************************************//


   return router;
}