module.exports = function(router, db){ 
//*******************************API - GET***********************************************************//
router.get('/get_mas_holiday_master',(req,res)=>{
 var query =  " select * from mas_holiday_master  where active_flag=1 "; 
 db.query(query,function(err,response){  
 if(err){     
 console.log(err);  
  res.send({ status: 0, msg: 'Failed', data: err }); 
 }else{   
  res.send({ status: 1, msg: 'Success', data: response }); 
  }  
  });  
}); 
//*******************************API - POST***********************************************************//
router.post('/insert_mas_holiday_master',(req,res)=>{
var reqParams = req.body;
var query =  " INSERT INTO mas_holiday_master ( holiday_date,applicable_religion,active_flag,created_by,created_on,modified_by,modified_on ) values ( '" +reqParams.holiday_date +"' ,'" +reqParams.applicable_religion +"' ,'" +reqParams.active_flag +"' ,'" +reqParams.created_by +"' ,'" +reqParams.created_on +"' ,'" +reqParams.modified_by +"' ,'" +reqParams.modified_on +"' ) "; 
 db.query(query,function(err,response){  
 if(err){     
 console.log(err);  
  res.send({ status: 0, msg: 'Failed', data: err }); 
 }else{   
  res.send({ status: 1, msg: 'Success', data: response }); 
  }  
  });  
}); 
// *******************************API - Edit***********************************************************//
router.put('/edit_mas_holiday_master',(req,res)=>{
var reqParams = req.body;
var query =  " update mas_holiday_master set holiday_date =  '"+reqParams.holiday_date +"',applicable_religion =  '"+reqParams.applicable_religion +"',active_flag =  '"+reqParams.active_flag +"',created_by =  '"+reqParams.created_by +"',created_on =  '"+reqParams.created_on +"',modified_by =  '"+reqParams.modified_by +"',modified_on =  '"+reqParams.modified_on +"' Where  id = '"+reqParams.id+ "' " ; 
 db.query(query,function(err,response){  
 if(err){     
 console.log(err);  
  res.send({ status: 0, msg: 'Failed', data: err }); 
 }else{   
  res.send({ status: 1, msg: 'Success', data: response }); 
  }  
  });  
})
//*******************************API - Delete***********************************************************//
router.delete('/deletemas_holiday_master',(req,res)=>{
var reqParams = req.body;
var query =  " update mas_holiday_master set active_flag=0 Where  id = '"+reqParams.id+ "' " ; 
 db.query(query,function(err,response){  
 if(err){     
 console.log(err);  
  res.send({ status: 0, msg: 'Failed', data: err }); 
 }else{   
  res.send({ status: 1, msg: 'Success', data: response }); 
  }  
  });  
})
return router; }    
