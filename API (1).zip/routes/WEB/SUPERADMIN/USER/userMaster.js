module.exports = function(router, db) {
  //*******************************API - GET***********************************************************//
  router.get("/getuser", function(req, res) {
    try {
      var query =
        "select mas_user_master.id,user_name,phone as mobileno,email, mas_user_type.user_type, user_type_id,  mas_group_master.groupname,groupid from mas_user_master inner join mas_user_type on  mas_user_type.id=mas_user_master.user_type_id inner join mas_group_master on mas_group_master.id=mas_user_master.groupid and mas_user_master.active_flag=1 and mas_user_type.active_flag=1";
      db.query(query, function(err, response) {
        if (err) {
          console.log(err);
        } else {
          res.send({ status: 1, msg: "Success", data: response });
        }
      });
    } catch (err) {
      res.send({ status: 0, msg: "Error", data: [] });
    }
  });

  //*******************************API - Insert***********************************************************//
  router.post("/insertuser", (req, res) => {
    query = "";
    reqParams = "";
    reqParams = req.body;
    //query="select * from getSpeciality";
    // is_admin =1 for super admin
    // is_admin =2 for web admin
    query =
      "INSERT INTO `mas_user_master` ( `groupid`, `user_type_id`, `password`,`phone`,`user_name`,`created_by`,`created_on`) VALUES ('" +
      reqParams.groupId +
      "','" +
      reqParams.userTypeId +
      "','" +
      reqParams.password +
      "','" +
      reqParams.mobileno +
      "','" +
      reqParams.username +
      "','" +
      reqParams.created_by +
      "', CURDATE());";

    // query="INSERT INTO `mas_doctor_speciality` ( `speciality`, `created_by`, `created_on` )  VALUES ('"+reqParams.speciality+"','"+reqParams.created_by+"',CURDATE())";
    db.query(query, (err, data) => {
      if (err) {
        res.send({ status: 0, msg: "Failed", Error: err });
        console.log({ error: err });
      } else {
        var get_user_id = data.insertId;
        console.log({ data: data });
        console.log("User_ID " + get_user_id);

        db.query(query, (err, data) => {
          if (err) {
            res.send({ status: 0, msg: "Failed", Error: err });
          } else {
            query =
              "INSERT INTO `mas_user` ( `user_id`, `username`) VALUES ('" +
              get_user_id +
              "','" +
              reqParams.username +
              "') ";
            // res.send({ status: 0, msg: 'Failed', Error: err });
            insert_userInfo(db, res, query);
          }
        });
        //   res.send({status:1,msg:"Success",data:data})
      }
    });
  });

  // insert uername information
  function insert_userInfo(db, res, query) {
    db.query(query, (err, data) => {
      if (err) {
        res.send({ status: 0, msg: "Failed", Error: err });
      } else {
        res.send({ status: 1, msg: "Success", data: data });
      }
    });
  }

  //*******************************API - Edit***********************************************************//
  router.put("/edituser", (req, res) => {
    query = "";
    reqParams = "";
    reqParams = req.body;
    //query="select * from getSpeciality";
    // is_admin =1 for super admin
    // is_admin =2 for web admin
    query =
      "update `mas_user_master`  set  `user_name`=?,`groupid`=?, `user_type_id`=?, `password`=?,`phone`=?,`modified_by`=?,`modified_on`=CURDATE() where id='" +
      req.body.id +
      "';update `mas_user` set `username`=? where user_id='" +
      req.body.id +
      "'  ";
    // query="INSERT INTO `mas_doctor_speciality` ( `speciality`, `created_by`, `created_on` )  VALUES ('"+reqParams.speciality+"','"+reqParams.created_by+"',CURDATE())";

    db.query(
      query,
      [
        reqParams.username,
        reqParams.groupId,
        reqParams.userTypeId,
        reqParams.password,
        reqParams.mobileno,
        reqParams.modified_by,
        reqParams.username
      ],
      (err, data) => {
        if (err) {
          console.log({ error: err });
        } else {
          res.send({ status: 1, msg: "Success", data: data });
        }
      }
    );
  });
  //*******************************API - Delete***********************************************************//
  router.delete("/deleteuser", (req, res) => {
    query = "";
    reqParams = "";
    reqParams = req.body;
    //query="select * from getSpeciality";
    // is_admin =1 for super admin
    // is_admin =2 for web admin
    query =
      "update `mas_user_master`  set  `active_flag`='0', `modified_on`=CURDATE() where id='" +
      req.body.id +
      "';update `mas_user` set `active_flag`='0' where user_id='" +
      req.body.id +
      "'  ";
    // query="INSERT INTO `mas_doctor_speciality` ( `speciality`, `created_by`, `created_on` )  VALUES ('"+reqParams.speciality+"','"+reqParams.created_by+"',CURDATE())";
    //query="select 'success' as output";
    db.query(query, (err, data) => {
      if (err) {
        console.log({ error: err });
      } else {
        res.send({ status: 1, msg: "Success", data: data });
      }
    });
  });

  router.post("/getModuleData", (req, res) => {
    var query =
      "SELECT id,module_name as Module FROM `mas_module_master` WHERE active_flag = 1";
    db.query(query, async (err, response) => {
      if (err) {
        console.log(err);
      } else {
        // res.send(response);
        console.log("Length:" + response.length);
        for (i = 0; i < response.length; i++) {
          response[i].submodule = await getDataFromSubModule(response[i].id);
        }
        res.send(response);
      }
    });
  });

  function getDataFromSubModule(moduleId) {
    return new Promise((resolve, reject) => {
      var query =
        "SELECT mas_sub_module_master.id AS SubMOduleId,submodule_name  FROM `mas_sub_module_master` LEFT JOIN mas_module_master ON mas_module_master.id = mas_sub_module_master.id WHERE mas_sub_module_master.module_id = '" +
        moduleId +
        "';";

      db.query(query, async (err, response) => {
        if (err) {
          console.log(err);
        } else {
          for (i = 0; i < response.length; i++) {
            console.log({ resp: response[i] });
            response[i].subModuleOfSubModule = await subModuleOfSubModule(
              response[i].SubMOduleId,
              moduleId
            );
          }
          resolve(response);
        }
      });
    });
  }

  function subModuleOfSubModule(subModuleId, moduleId) {
    return new Promise((resolve, reject) => {
      var query =
        "SELECT mas_screen_master.id AS screenId,screen_name,mas_group_permission.allow_add,mas_group_permission.allow_edit,mas_group_permission.allow_delete,mas_group_permission.allow_view,mas_group_permission.allow_print FROM `mas_screen_master` LEFT JOIN mas_group_permission ON mas_group_permission.screen_master_id = mas_screen_master.id WHERE moduleid = '" +
        moduleId +
        "' and submoduleid = '" +
        subModuleId +
        "'";

      db.query(query, async (err, response) => {
        if (err) {
          console.log(err);
        } else {
          resolve(response);
        }
      });
    });
  }

  return router;
};
//*******************************EOL***********************************************************//
