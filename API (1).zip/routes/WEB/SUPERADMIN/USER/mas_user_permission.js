module.exports = function(router, db){ 
//*******************************API - GET***********************************************************//
router.get('/get_mas_user_permission',(req,res)=>{
 var query =  " select * from mas_user_permission  where active_flag=1 "; 
 db.query(query,function(err,response){  
 if(err){     
 console.log(err);  
  res.send({ status: 0, msg: 'Failed', data: err }); 
 }else{   
  res.send({ status: 1, msg: 'Success', data: response }); 
  }  
  });  
}); 
//*******************************API - POST***********************************************************//
router.post('/insert_mas_user_permission',(req,res)=>{
var reqParams = req.body;
var query =  " INSERT INTO mas_user_permission ( user_id,screen_master_id,allow_add,allow_edit,allow_delete,allow_view,allow_print,active_flag,created_by,created_on,modified_by,modified_on ) values ( '" +reqParams.user_id +"' ,'" +reqParams.screen_master_id +"' ,'" +reqParams.allow_add +"' ,'" +reqParams.allow_edit +"' ,'" +reqParams.allow_delete +"' ,'" +reqParams.allow_view +"' ,'" +reqParams.allow_print +"' ,'" +reqParams.active_flag +"' ,'" +reqParams.created_by +"' ,'" +reqParams.created_on +"' ,'" +reqParams.modified_by +"' ,'" +reqParams.modified_on +"' ) "; 
 db.query(query,function(err,response){  
 if(err){     
 console.log(err);  
  res.send({ status: 0, msg: 'Failed', data: err }); 
 }else{   
  res.send({ status: 1, msg: 'Success', data: response }); 
  }  
  });  
}); 
// *******************************API - Edit***********************************************************//
router.put('/edit_mas_user_permission',(req,res)=>{
var reqParams = req.body;
var query =  " update mas_user_permission set user_id =  '"+reqParams.user_id +"',screen_master_id =  '"+reqParams.screen_master_id +"',allow_add =  '"+reqParams.allow_add +"',allow_edit =  '"+reqParams.allow_edit +"',allow_delete =  '"+reqParams.allow_delete +"',allow_view =  '"+reqParams.allow_view +"',allow_print =  '"+reqParams.allow_print +"',active_flag =  '"+reqParams.active_flag +"',created_by =  '"+reqParams.created_by +"',created_on =  '"+reqParams.created_on +"',modified_by =  '"+reqParams.modified_by +"',modified_on =  '"+reqParams.modified_on +"' Where  id = '"+reqParams.id+ "' " ; 
 db.query(query,function(err,response){  
 if(err){     
 console.log(err);  
  res.send({ status: 0, msg: 'Failed', data: err }); 
 }else{   
  res.send({ status: 1, msg: 'Success', data: response }); 
  }  
  });  
}) 

//*******************************API - Delete***********************************************************//
router.delete('/deletemas_user_permission',(req,res)=>{
var reqParams = req.body;
var query =  " update mas_user_permission set active_flag=0 Where  id = '"+reqParams.id+ "' " ; 
 db.query(query,function(err,response){  
 if(err){     
 console.log(err);  
  res.send({ status: 0, msg: 'Failed', data: err }); 
 }else{   
  res.send({ status: 1, msg: 'Success', data: response }); 
  }  
  }); 
}) 
return router; }    
