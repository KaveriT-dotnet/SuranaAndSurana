module.exports = function(router,db){

//*******************************API - GET***********************************************************//

router.get('/getuserType',function(req, res) { 
try{   
    var query = "select id,user_type from mas_user_type where active_flag=1";
    db.query(query,function(err,response){ 
    if(err){    
      console.log(err);    
    }else{ 
       res.send({ status: 1, msg: 'Success', data: response }); 
    }   
  })
}
 catch (err) {      
    res.send({ status: 0, msg: 'Error', data: [] })
  }  
 
});
 
//*******************************API - Insert***********************************************************//
  router.post('/insertuserType',(req,res)=>{
    
     query=""; 
     reqParams="";  
     reqParams=req.body;
     //query="select * from getSpeciality";
     // is_admin =1 for super admin
     // is_admin =2 for web admin  
     query= "INSERT INTO `mas_user_type` ( `user_type`, `created_on`) VALUES ('"+reqParams.userType+"', CURDATE())";
     // query="INSERT INTO `mas_doctor_speciality` ( `speciality`, `created_by`, `created_on` )  VALUES ('"+reqParams.speciality+"','"+reqParams.created_by+"',CURDATE())";
    db.query(query,(err,data)=>{
    if(err) 
    {   
        // res.send({ status: 0, msg: 'Failed', Error: err }); 
       console.log({error:err});  
        res.send({status:0,msg:"Failed",data:data})   ;
    //      } 

    }
   else   
    {       res.send({status:1,msg:"Success",data:data})     }
    }     ) 
  });

//*******************************API - Edit***********************************************************//
router.put('/edituserType',(req,res)=>{    
     query="";  
     reqParams="";  
     reqParams=req.body;
     //query="select * from getSpeciality";
     // is_admin =1 for super admin
     // is_admin =2 for web admin
    query= "update `mas_user_type`  set  `user_type`='"+reqParams.userType+"', `modified_on`=CURDATE() where id='"+req.body.id+"' ";
    // query="INSERT INTO `mas_doctor_speciality` ( `speciality`, `created_by`, `created_on` )  VALUES ('"+reqParams.speciality+"','"+reqParams.created_by+"',CURDATE())";
       
    db.query(query,(err,data)=>{
    if(err) 
    {      console.log({error:err})   }
   else   
    {       res.send({status:1,msg:"Success",data:data})     }
    }     ) 
  });
//*******************************API - Delete***********************************************************//
 
router.delete('/deleteuserType',(req,res)=>{    
     query=""; 
     reqParams=""; 
     reqParams=req.body;
     //query="select * from getSpeciality";
     // is_admin =1 for super admin
     // is_admin =2 for web admin
    query= "update `mas_user_type`  set  `active_flag`='0', `modified_on`=CURDATE() where id='"+req.body.id+"' ";
    // query="INSERT INTO `mas_doctor_speciality` ( `speciality`, `created_by`, `created_on` )  VALUES ('"+reqParams.speciality+"','"+reqParams.created_by+"',CURDATE())";
    //query="select 'success' as output"; 
    db.query(query,(err,data)=>{
    if(err) 
    {      console.log({error:err})   }
   else   
    {       res.send({status:1,msg:"Success",data:data})     }
    }     )  
  }); 
return router;
}   
 
//*******************************EOL***********************************************************//
