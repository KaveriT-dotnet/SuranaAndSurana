module.exports = function(router, db){ 
//*******************************API - GET***********************************************************//
router.get('/get_mas_user',(req,res)=>{
 var query =  " select * from mas_user  where active_flag=1 "; 
 db.query(query,function(err,response){  
 if(err){     
 console.log(err);  
  res.send({ status: 0, msg: 'Failed', data: err }); 
 }else{   
  res.send({ status: 1, msg: 'Success', data: response }); 
  }  
  });  
}); 
//*******************************API - POST***********************************************************//
router.post('/insert_mas_user',(req,res)=>{
var reqParams = req.body;
var query =  " INSERT INTO mas_user ( user_id,username,active_flag ) values ( '" +reqParams.user_id +"' ,'" +reqParams.username +"' ,'" +reqParams.active_flag +"' ) "; 
 db.query(query,function(err,response){  
 if(err){     
 console.log(err);  
  res.send({ status: 0, msg: 'Failed', data: err }); 
 }else{   
  res.send({ status: 1, msg: 'Success', data: response }); 
  }  
  });  
}); 
// *******************************API - Edit***********************************************************//
router.put('/edit_mas_user',(req,res)=>{
var reqParams = req.body;
var query =  " update mas_user set user_id =  '"+reqParams.user_id +"',username =  '"+reqParams.username +"',active_flag =  '"+reqParams.active_flag +"' Where  id = '"+reqParams.id+ "' " ; 
 db.query(query,function(err,response){  
 if(err){     
 console.log(err);  
  res.send({ status: 0, msg: 'Failed', data: err }); 
 }else{   
  res.send({ status: 1, msg: 'Success', data: response }); 
  }  
  });  
}) 

//*******************************API - Delete***********************************************************//
router.delete('/deletemas_user',(req,res)=>{
var reqParams = req.body;
var query =  " update mas_user set active_flag=0 Where  id = '"+reqParams.id+ "' " ; 
 db.query(query,function(err,response){  
 if(err){     
 console.log(err);  
  res.send({ status: 0, msg: 'Failed', data: err }); 
 }else{   
  res.send({ status: 1, msg: 'Success', data: response }); 
  }  
  });
}) 

return router; }    
