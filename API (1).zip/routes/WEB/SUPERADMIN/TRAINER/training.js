module.exports = function(router, db, errorCode) {
  router.post("/insertTraining", (req, res) => {
    try {
      var validationStatus = true;
      var Errors = [];
      var responseJson = {};

      if (req.body) {
        if (
          typeof req.body.trainingName == null ||
          req.body.trainingName == undefined ||
          req.body.trainingName == ""
        ) {
          Errors.push("trainingName is empty or incorrect");
          validationStatus = false;
        } else {
          req.body.trainingName;
        }
        if (
          typeof req.body.trainingCatId == null ||
          req.body.trainingCatId == undefined ||
          req.body.trainingCatId == ""
        ) {
          Errors.push("trainingCatId is empty or incorrect");
          validationStatus = false;
        } else {
          req.body.trainingCatId;
        }
        if (
          typeof req.body.createdBy == null ||
          req.body.createdBy == undefined ||
          req.body.createdBy == ""
        ) {
          Errors.push("createdBy is empty or incorrect");
          validationStatus = false;
        } else {
          req.body.createdBy;
        }
      } else {
        Errors.push("Request Body is empty");
        validationStatus = false;
      }
      if (!validationStatus) {
        responseJson.status = 0;
        responseJson.msg = "Invalida Request Body";
        responseJson.payload = Errors;
        return res.send(responseJson);
      } else {
        var queryParams = req.body;

        var query =
          "INSERT INTO `mas_training`(`training`, `trainingcategory_id`, `active_flag`, `created_by`, `created_on`) VALUES ('" +
          queryParams.trainingName +
          "','" +
          queryParams.trainingCatId +
          "',1,'" +
          queryParams.createdBy +
          "',NOW())";
        db.query(query, (err, response) => {
          if (err) {
            console.log(err);
            console.log(errorCode);
            res.send(errorCode.errorCodeResponse(err.errno));
          } else {
            if (response.affectedRows == 0) {
              res.send({ status: 0, msg: "Not Inserted", data: [] });
            } else {
              res.send({
                status: 1,
                msg: "Training Successfully Inserted",
                data: []
              });
            }
          }
        });
      }
    } catch {
      res.send({ status: 0, msg: "Internal Server Error", data: [] });
    }
  });

  router.post("/updateTraining", (req, res) => {
    try {
      var validationStatus = true;
      var Errors = [];
      var responseJson = {};

      if (req.body) {

        Object.entries(req.body).map((bodyKey, i) => {
          if (
            typeof bodyKey[1] == null ||
            bodyKey[1] == undefined ||
            bodyKey[1] == ""
          ) {
            console.log("comming");
            Errors.push(`${bodyKey[0]} is empty or incorrect`);
            validationStatus = false;
          } else {
            bodyKey[i];
          }
        });

      } else {
        Errors.push("Request Body is empty");
        validationStatus = false;
      }
      if (!validationStatus) {
        responseJson.status = 0;
        responseJson.msg = "Invalida Request Body";
        responseJson.payload = Errors;
        return res.send(responseJson);
      } else {
        var queryParams = req.body;

        var query =
          "UPDATE `mas_training` SET `training`='" +
          queryParams.trainingName +
          "',`modified_by`='" +
          queryParams.updatedBy +
          "',`modified_on`=NOW() WHERE mas_training.`id`='" +
          queryParams.trainingId +
          "';";
        db.query(query, (err, response) => {
          if (err) {
            console.log(err);
            console.log(errorCode);
            res.send(errorCode.errorCodeResponse(err.errno));
          } else {
            console.log(response);
            if (response.affectedRows == 0) {
              res.send({
                status: 0,
                msg: "Trainer Category Not Updated",
                data: []
              });
            } else {
              res.send({
                status: 1,
                msg: "Tariner Category Updated Successfully",
                data: []
              });
            }
          }
        });
      }
    } catch {
      res.send({ status: 0, msg: "Validation Error", data: [] });
    }
  });

  router.post("/deleteTraining", (req, res) => {
    try {
      var validationStatus = true;
      var Errors = [];
      var responseJson = {};

      if (req.body) {
        Object.entries(req.body).map((bodyKey, i) => {
          if (
            typeof bodyKey[1] == null ||
            bodyKey[1] == undefined ||
            bodyKey[1] == ""
          ) {
            Errors.push(`${bodyKey[0]} is empty or incorrect`);
            validationStatus = false;
          } else {
            bodyKey[i];
          }
        });
      } else {
        Errors.push("Request Body is empty");
        validationStatus = false;
      }
      if (!validationStatus) {
        responseJson.status = 0;
        responseJson.message = "Invalida Request Body";
        responseJson.payload = Errors;
        return res.send(responseJson);
      } else {
        var queryParams = req.body;

          var query =
          "UPDATE `mas_training` SET `active_flag` = '0',`modified_by`='" +
          queryParams.updatedBy +
          "',`modified_on`=NOW()  WHERE mas_training.`id`='" +
          queryParams.trainingId +
          "';";
        db.query(query, (err, response) => {
          if (err) {
            console.log(err);
            console.log(errorCode);
            res.send(errorCode.errorCodeResponse(err.errno));
          } else {
            console.log(response);
            if (response.affectedRows == 0) {
              res.send({
                status: 0,
                msg: "Training is Not Deleted",
                data: []
              });
            } else {
              res.send({
                status: 1,
                msg: "Training Deleted Successfully",
                data: []
              });
            }
          }
        });
      }
    } catch {
      res.send({ status: 0, msg: "Validation Error", data: [] });
    }
  });

  router.post("/getTrainingList", (req, res) => {
    var query =
      "SELECT mas_training.id AS trainingId,training AS trainingName,mas_trainingcategory.id AS trainingCatId,mas_trainingcategory.training_category FROM `mas_training` INNER JOIN mas_trainingcategory ON mas_trainingcategory.id = mas_training.trainingcategory_id WHERE mas_training.active_flag = 1 AND mas_trainingcategory.active_flag = 1";

    db.query(query, (err, response) => {
      if (err) {
        console.log(err);
        res.send(errorCode.errorCodeResponse(err.errno));
      } else {
        if (response.length > 0) {
          res.send({
            status: 1,
            msg: "Success",
            data: response
          });
        } else {
          res.send({
            status: 0,
            msg: "Data is Empty",
            data: response
          });
        }
      }
    });
  });

  return router;
};
