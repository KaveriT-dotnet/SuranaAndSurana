module.exports = function(router, db){ 
//*******************************API - GET***********************************************************//
router.get('/get_mas_trainer',(req,res)=>{
 var query =  " select * from mas_trainer  where active_flag=1 "; 
 db.query(query,function(err,response){  
 if(err){     
 console.log(err);  
  res.send({ status: 0, msg: 'Failed', data: err }); 
 }else{   
  res.send({ status: 1, msg: 'Success', data: response }); 
  }  
  });  
}); 
//*******************************API - POST***********************************************************//
router.post('/insert_mas_trainer',(req,res)=>{
var reqParams = req.body;
var query =  " INSERT INTO mas_trainer ( training,trainer_trainingcategory_id,active_flag,created_by,created_on,modified_by,modified_on ) values ( '" +reqParams.training +"' ,'" +reqParams.trainer_trainingcategory_id +"' ,'" +reqParams.active_flag +"' ,'" +reqParams.created_by +"' ,'" +reqParams.created_on +"' ,'" +reqParams.modified_by +"' ,'" +reqParams.modified_on +"' ) "; 
 db.query(query,function(err,response){  
 if(err){     
 console.log(err);  
  res.send({ status: 0, msg: 'Failed', data: err }); 
 }else{   
  res.send({ status: 1, msg: 'Success', data: response }); 
  }  
  });  
}); 
// *******************************API - Edit***********************************************************//
router.put('/edit_mas_trainer',(req,res)=>{
var reqParams = req.body;
var query =  " update mas_trainer set training =  '"+reqParams.training +"',trainer_trainingcategory_id =  '"+reqParams.trainer_trainingcategory_id +"',active_flag =  '"+reqParams.active_flag +"',created_by =  '"+reqParams.created_by +"',created_on =  '"+reqParams.created_on +"',modified_by =  '"+reqParams.modified_by +"',modified_on =  '"+reqParams.modified_on +"' Where  id = '"+reqParams.id+ "' " ; 
 db.query(query,function(err,response){  
 if(err){     
 console.log(err);  
  res.send({ status: 0, msg: 'Failed', data: err }); 
 }else{   
  res.send({ status: 1, msg: 'Success', data: response }); 
  }  
  }); 
}) 

//*******************************API - Delete***********************************************************//
router.delete('/deletemas_trainer',(req,res)=>{
var reqParams = req.body;
var query =  " update mas_trainer set active_flag=0 Where  id = '"+reqParams.id+ "' " ; 
 db.query(query,function(err,response){  
 if(err){     
 console.log(err);  
  res.send({ status: 0, msg: 'Failed', data: err }); 
 }else{   
  res.send({ status: 1, msg: 'Success', data: response }); 
  }  
  });
}) 

return router; }    
