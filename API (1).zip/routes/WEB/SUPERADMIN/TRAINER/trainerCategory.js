module.exports = function(router, db, errorCode) {

    router.post("/insertTrainerCategory", (req, res) => {
      try {
        var validationStatus = true;
        var Errors = [];
        var responseJson = {};
  
        if (req.body) {
          Object.entries(req.body).map((bodyKey, i) => {
            if (
              typeof bodyKey[1] == null ||
              bodyKey[1] == undefined ||
              bodyKey[1] == ""
            ) {
              Errors.push(`${bodyKey[0]} is empty or incorrect`);
              validationStatus = false;
            } else {
              bodyKey[i];
            }
          });
        } else {
          Errors.push("Request Body is empty");
          validationStatus = false;
        }
        if (!validationStatus) {
          responseJson.status = 0;
          responseJson.msg = "Invalida Request Body";
          responseJson.payload = Errors;
          return res.send(responseJson);
        } else {
          var queryParams = req.body;

        var query = "INSERT INTO `mas_tr_trainingcategory`(`training_category`, `active_flag`, `created_by`, `created_on`) VALUES ('"+queryParams.trainerCatName+"',1,'"+queryParams.createdBy+"',NOW())"
          db.query(query, (err, response) => {
            if (err) {
              console.log(err);
              console.log(errorCode);
              res.send(errorCode.errorCodeResponse(err.errno));
            } else {
              if (response.affectedRows == 0) {
                  res.send({ status: 0, msg: "Not Inserted", data: [] });
                }else{
                  res.send({ status: 1, msg: "Successfully Inserted", data: [] });
                }
            }
          });
        }
      } catch {
        res.send({ status: 0, msg: "Internal Server Error", data: [] });
      }
    });
  
    router.post("/updateTrainerCategory", (req, res) => {
      try {
        var validationStatus = true;
        var Errors = [];
        var responseJson = {};
  
        if (req.body) {
          Object.entries(req.body).map((bodyKey, i) => {
            if (
              typeof bodyKey[1] == null ||
              bodyKey[1] == undefined ||
              bodyKey[1] == ""
            ) {
              Errors.push(`${bodyKey[0]} is empty or incorrect`);
              validationStatus = false;
            } else {
              bodyKey[i];
            }
          });
        } else {
          Errors.push("Request Body is empty");
          validationStatus = false;
        }
        if (!validationStatus) {
          responseJson.status = 0;
          responseJson.msg = "Invalida Request Body";
          responseJson.payload = Errors;
          return res.send(responseJson);
        } else {
          var queryParams = req.body;
  
          var query =
            "UPDATE `mas_tr_trainingcategory` SET `training_category`='"+queryParams.trainerCatName+"',`modified_by`='"+queryParams.updatedBy+"',`modified_on`=NOW() WHERE mas_tr_trainingcategory.`id`='"+queryParams.trainerCatId+"';";
        
          db.query(query, (err, response) => {
            if (err) {
              console.log(err);
              console.log(errorCode);
              res.send(errorCode.errorCodeResponse(err.errno));
            } else {
              console.log(response);
              if (response.affectedRows == 0) {
                res.send({ status: 0, msg: "Trainer Category Not Updated", data: [] });
              } else {
                res.send({
                  status: 1,
                  msg: "Tariner Category Updated Successfully",
                  data: []
                });
              }
            }
          });
        }
      } catch {
        res.send({ status: 0, msg: "Validation Error", data: [] });
      }
    });
  
  router.post("/deleteTrainerCategory", (req, res) => {
      try {
        var validationStatus = true;
        var Errors = [];
        var responseJson = {};
  
        if (req.body) {
          Object.entries(req.body).map((bodyKey, i) => {
            if (
              typeof bodyKey[1] == null ||
              bodyKey[1] == undefined ||
              bodyKey[1] == ""
            ) {
              Errors.push(`${bodyKey[0]} is empty or incorrect`);
              validationStatus = false;
            } else {
              bodyKey[i];
            }
          });
        } else {
          Errors.push("Request Body is empty");
          validationStatus = false;
        }
        if (!validationStatus) {
          responseJson.status = 0;
          responseJson.message = "Invalida Request Body";
          responseJson.payload = Errors;
          return res.send(responseJson);
        } else {
          var queryParams = req.body;
            var query = "UPDATE `mas_tr_trainingcategory` SET `active_flag` = '0',`modified_by`='" +
            queryParams.updatedBy +
            "',`modified_on`=NOW() WHERE mas_tr_trainingcategory.`id`='"+queryParams.trainerCatId+"';"
          db.query(query, (err, response) => {
            if (err) {
              console.log(err);
              console.log(errorCode);
              res.send(errorCode.errorCodeResponse(err.errno));
            } else {
              console.log(response);
              if (response.affectedRows == 0) {
                res.send({ status: 0, msg: "Trainer Category is Not Deleted", data: [] });
              } else {
                res.send({
                  status: 1,
                  msg: "Trainer Category Deleted Successfully",
                  data: []
                });
              }
            }
          });
        }
      } catch {
        res.send({ status: 0, msg: "Validation Error", data: [] });
      }
    });
  
  router.post("/getTrainerCategoryList",(req,res)=>{
  
      var query = "SELECT id AS trainerCatId,training_category AS trainerCatName FROM `mas_tr_trainingcategory` WHERE mas_tr_trainingcategory.active_flag =1";
  
      db.query(query,(err,response)=>{
          if(err){
              console.log(err);
              res.send(errorCode.errorCodeResponse(err.errno));
          }else{
              if(response.length > 0){
  
                  res.send({
                      status: 1,
                      msg: "Success",
                      data: response
                    });
              }else{
                  res.send({
                      status: 0,
                      msg: "Data is Empty",
                      data: response
                    });
  
              }
          }
  
      })
  })
  
    return router;
  };
  