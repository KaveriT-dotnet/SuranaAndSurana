module.exports = function(router, db){ 
//*******************************API - GET***********************************************************//
router.get('/get_mas_commission',(req,res)=>{
 var query =  " select * from mas_commission  where active_flag=1 "; 
 db.query(query,function(err,response){  
 if(err){     
 console.log(err);  
  res.send({ status: 0, msg: 'Failed', data: err }); 
 }else{   
  res.send({ status: 1, msg: 'Success', data: response }); 
  }  
  });  
}); 
//*******************************API - POST***********************************************************//
router.post('/insert_mas_commission',(req,res)=>{
var reqParams = req.body;
var query =  " INSERT INTO mas_commission ( vendor,commission,active_flag,created_by,created_on,modified_by,modified_on ) values ( '" +reqParams.vendor +"' ,'" +reqParams.commission +"' ,'" +reqParams.active_flag +"' ,'" +reqParams.created_by +"' ,'" +reqParams.created_on +"' ,'" +reqParams.modified_by +"' ,'" +reqParams.modified_on +"' ) "; 
 db.query(query,function(err,response){  
 if(err){     
 console.log(err);  
  res.send({ status: 0, msg: 'Failed', data: err }); 
 }else{   
  res.send({ status: 1, msg: 'Success', data: response }); 
  }  
  });  
}); 
// *******************************API - Edit***********************************************************//
router.put('/edit_mas_commission',(req,res)=>{
var reqParams = req.body;
var query =  " update mas_commission set vendor =  '"+reqParams.vendor +"',commission =  '"+reqParams.commission +"',active_flag =  '"+reqParams.active_flag +"',created_by =  '"+reqParams.created_by +"',created_on =  '"+reqParams.created_on +"',modified_by =  '"+reqParams.modified_by +"',modified_on =  '"+reqParams.modified_on +"' Where  id = '"+reqParams.id+ "' " ; 
 db.query(query,function(err,response){  
 if(err){     
 console.log(err);  
  res.send({ status: 0, msg: 'Failed', data: err }); 
 }else{   
  res.send({ status: 1, msg: 'Success', data: response }); 
  }  
  }); 
})
//*******************************API - Delete***********************************************************//
router.delete('/deletemas_commission',(req,res)=>{
var reqParams = req.body;
var query =  " update mas_commission set active_flag=0 Where  id = '"+reqParams.id+ "' " ; 
 db.query(query,function(err,response){  
 if(err){     
 console.log(err);  
  res.send({ status: 0, msg: 'Failed', data: err }); 
 }else{   
  res.send({ status: 1, msg: 'Success', data: response }); 
  }  
  });
});
return router; 
}    
