module.exports = function(router,db){

router.post("/getmodule",function(req, res) {
try{ 
  var query = "select id,module_name from mas_module_master";
  db.query(query,function(err,response){ 
    if(err){  
      console.log(err);
    }else{ 
      res.send({ status: 1, msg: 'Success', data: response });
    }   
  })

} catch (err) {
    console.log("CatchError", err.message);
    console.log("CatchError", err); 
    res.send({ status: 0, msg: 'validation Error', data: [] })
  }

});

//*******************************API - Insert***********************************************************//
  router.post('/insertSpeciality',(req,res)=>{
     
     query=""; 
     reqParams="";
     reqParams=req.body;
     //query="select * from getSpeciality";

     query="INSERT INTO `mas_doctor_speciality` ( `speciality`, `created_by`, `created_on` )  VALUES ('"+reqParams.speciality+"','"+reqParams.created_by+"',CURDATE())";
     
     //query="select 'success' as output";
    db.query(query,(err,data)=>{
    if(err) 
    {      console.log({error:err})   }
   else   
    {       res.send({status:1,msg:"Success",data:data})     }
    }     ) 

  });



return router;


}