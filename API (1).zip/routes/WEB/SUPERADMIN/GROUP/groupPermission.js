module.exports = function(router,db){


//*******************************API - Select***********************************************************//
router.get('/getgroupPermission',(req,res)=>{
	var reqParam=req.body;
    var query="";  
    if(reqParam.groupid==null || reqParam.groupid==undefined)
    {
     //query="select * from getSpeciality";    
    query="SELECT screen_name, module_name, submodule_name, moduleid, submoduleid,mas_screen_master.id as screen_id, 'N' allow_add ,'N' allow_edit ,'N' allow_delete,'N' allow_view,'N' allow_print  FROM `mas_screen_master` inner join mas_module_master on mas_module_master.id=mas_screen_master.moduleid and mas_screen_master.active_flag=1 left join mas_sub_module_master on mas_sub_module_master.id=mas_screen_master.submoduleid and mas_sub_module_master.active_flag=1  order by moduleid,submoduleid,mas_screen_master.id";
   }
   else
   {
	query="SELECT screen_name, module_name, submodule_name, moduleid, submoduleid,mas_screen_master.id as screen_id, allow_add ,allow_edit ,allow_delete,allow_view,allow_print FROM `mas_screen_master` inner join mas_module_master on mas_module_master.id=mas_screen_master.moduleid left join mas_sub_module_master on mas_sub_module_master.id=mas_screen_master.submoduleid  and mas_screen_master.active_flag=1 inner join mas_group_permission on mas_group_permission.screen_master_id= mas_screen_master.id  and mas_sub_module_master.active_flag=1 where mas_group_permission.group_id='"+ reqParams.groupid+"' order by moduleid,submoduleid,mas_screen_master.id ";
    }

    db.query(query,(err,data)=>{  
    if(err) 
    {      console.log({error:err.error})  

    }
    else   
    {     res.send({status:1,msg:"Success",data:data}) 

        }
    }    	)

  });
    
//*******************************API - Select***********************************************************//

router.post('/insertgroupPermission',(req,res)=>{
	var reqParam=req.body;
    var query="";  
    if(reqParam.groupid==null || reqParam.groupid==undefined)
    {
     //query="select * from getSpeciality";    
    query="SELECT screen_name, module_name, submodule_name, moduleid, submoduleid,mas_screen_master.id as screen_id, 'N' allow_add ,'N' allow_edit ,'N' allow_delete,'N' allow_view,'N' allow_print  FROM `mas_screen_master` inner join mas_module_master on mas_module_master.id=mas_screen_master.moduleid left join mas_sub_module_master on mas_sub_module_master.id=mas_screen_master.submoduleid order by moduleid,submoduleid,mas_screen_master.id";
   }
   else
   {                
	query="SELECT screen_name, module_name, submodule_name, moduleid, submoduleid,mas_screen_master.id as screen_id, allow_add ,allow_edit ,allow_delete,allow_view,allow_print FROM `mas_screen_master` inner join mas_module_master on mas_module_master.id=mas_screen_master.moduleid left join mas_sub_module_master on mas_sub_module_master.id=mas_screen_master.submoduleid inner join mas_group_permission on mas_group_permission.screen_master_id= mas_screen_master.id where mas_group_permission.group_id='"+ reqParams.groupid+"' order by moduleid,submoduleid,mas_screen_master.id ";
    } 
    db.query(query,(err,data)=>{  
    if(err) 
    {      console.log({error:err.error})  

    }
    else   
    {     res.send({status:1,msg:"Success",data:data}) 

    }
    })
 
  });

return router;

}