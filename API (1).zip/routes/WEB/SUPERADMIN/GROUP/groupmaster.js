module.exports = function(router,db){

router.get('/getGroup',function(req, res) {
try{    
  var query = "select id,groupname from mas_group_master where active_flag=1";
  db.query(query,function(err,response){ 
    if(err){   
      console.log(err); 
    }else{   
      res.send({ status: 1, msg: 'Success', data: response });
    }    
  })
}
 catch (err) { 
    
    res.send({ status: 0, msg: 'Error', data: [] })
  }

}); 

//*******************************API - Insert***********************************************************//
  router.post('/insertGroup',(req,res)=>{
    
     query=""; 
     reqParams=""; 
     reqParams=req.body;
     //query="select * from getSpeciality";
     // is_admin =1 for super admin
     // is_admin =2 for web admin  
     query= "INSERT INTO `mas_group_master` ( `groupname`,   `created_by`, `created_on`) VALUES ('"+reqParams.groupname+"',  '"+reqParams.created_by+"', CURDATE())";
     // query="INSERT INTO `mas_doctor_speciality` ( `speciality`, `created_by`, `created_on` )  VALUES ('"+reqParams.speciality+"','"+reqParams.created_by+"',CURDATE())";
    db.query(query,(err,data)=>{
    if(err) 
    {      console.log({error:err})   }
   else   
    {       res.send({status:1,msg:"Success",data:data})     }
    }     ) 
  });


router.put('/editGroup',(req,res)=>{    
     query=""; 
     reqParams="";
     reqParams=req.body;
     //query="select * from getSpeciality";
     // is_admin =1 for super admin
     // is_admin =2 for web admin
    query= "update `mas_group_master`  set  `groupname`='"+reqParams.groupname+"', `modified_by`='"+reqParams.modified_by+"', `modified_on`=CURDATE() where id='"+req.body.id+"' ";
    // query="INSERT INTO `mas_doctor_speciality` ( `speciality`, `created_by`, `created_on` )  VALUES ('"+reqParams.speciality+"','"+reqParams.created_by+"',CURDATE())";
       
    db.query(query,(err,data)=>{
    if(err) 
    {      console.log({error:err})   }
   else   
    {       res.send({status:1,msg:"Success",data:data})     }
    }     ) 
  });

router.delete('/deleteGroup',(req,res)=>{    
     query=""; 
     reqParams="";
     reqParams=req.body;
     //query="select * from getSpeciality";
     // is_admin =1 for super admin
     // is_admin =2 for web admin
    query= "update `mas_group_master`  set  `active_flag`='0', `modified_by`='"+reqParams.modified_by+"', `modified_on`=CURDATE() where id='"+req.body.id+"' ";
    // query="INSERT INTO `mas_doctor_speciality` ( `speciality`, `created_by`, `created_on` )  VALUES ('"+reqParams.speciality+"','"+reqParams.created_by+"',CURDATE())";
     
     //query="select 'success' as output";
    db.query(query,(err,data)=>{
    if(err) 
    {      console.log({error:err})   }
   else   
    {       res.send({status:1,msg:"Success",data:data})     }
    }     )  
  }); 
return router;
}
