module.exports = function(router, db, errorCode) {

  router.post("/insertHealthTip", (req, res) => {
    try {
      var validationStatus = true;
      var Errors = [];
      var responseJson = {};

      if (req.body) {
        if (
          typeof req.body.healthTipName == null ||
          req.body.healthTipName == undefined ||
          req.body.healthTipName == ""
        ) {
          Errors.push("healthTipName is empty or incorrect");
          validationStatus = false;
        } else {
          req.body.healthTipName;
        }
        if (
          typeof req.body.createdBy == null ||
          req.body.createdBy == undefined ||
          req.body.createdBy == ""
        ) {
          Errors.push("createdBy is empty or incorrect");
          validationStatus = false;
        } else {
          req.body.createdBy;
        }
      } else {
        Errors.push("Request Body is empty");
        validationStatus = false;
      }
      if (!validationStatus) {
        responseJson.status = 0;
        responseJson.message = "Invalida Request Body";
        responseJson.payload = Errors;
        return res.send(responseJson);
      } else {
        var queryParams = req.body;

        var query =
          "INSERT INTO `mas_to_healthtip`(`to_healthtip`, `created_by`, `created_on`) VALUES ('" +
          queryParams.healthTipName +
          "','" +
          queryParams.createdBy +
          "',NOW());";
        db.query(query, (err, response) => {
          if (err) {
            console.log(err);
            console.log(errorCode);
            res.send(errorCode.errorCodeResponse(err.errno));
          } else {
            if (response.affectedRows == 0) {
                res.send({ status: 0, msg: "Not Inserted", data: [] });
              }else{
                res.send({ status: 1, msg: "Success", data: [] });
              }
          }
        });
      }
    } catch {
      res.send({ status: 0, msg: "Internal Server Error", data: [] });
    }
  });

  router.post("/updateHealthTip", (req, res) => {
    try {
      var validationStatus = true;
      var Errors = [];
      var responseJson = {};

      if (req.body) {
        if (
          typeof req.body.healthTipName == null ||
          req.body.healthTipName == undefined ||
          req.body.healthTipName == ""
        ) {
          Errors.push("healthTipName is empty or incorrect");
          validationStatus = false;
        } else {
          req.body.healthTipName;
        }
        if (
          typeof req.body.healthTipId == null ||
          req.body.healthTipId == undefined ||
          req.body.healthTipId == ""
        ) {
          Errors.push("healthTipId is empty or incorrect");
          validationStatus = false;
        } else {
          req.body.healthTipId;
        }
        if (
          typeof req.body.updatedBy == null ||
          req.body.updatedBy == undefined ||
          req.body.updatedBy == ""
        ) {
          Errors.push("updatedBy is empty or incorrect");
          validationStatus = false;
        } else {
          req.body.updatedBy;
        }
      } else {
        Errors.push("Request Body is empty");
        validationStatus = false;
      }
      if (!validationStatus) {
        responseJson.status = 0;
        responseJson.message = "Invalida Request Body";
        responseJson.payload = Errors;
        return res.send(responseJson);
      } else {
        var queryParams = req.body;

        var query =
          "UPDATE `mas_to_healthtip` SET `to_healthtip`='" +
          queryParams.healthTipName +
          "',`modified_by`='" +
          queryParams.updatedBy +
          "',`modified_on`=NOW() WHERE mas_to_healthtip.`id`='" +
          queryParams.healthTipId +
          "';";
        db.query(query, (err, response) => {
          if (err) {
            console.log(err);
            console.log(errorCode);
            res.send(errorCode.errorCodeResponse(err.errno));
          } else {
            console.log(response);
            if (response.affectedRows == 0) {
              res.send({ status: 0, msg: "Health Tip Not Updated", data: [] });
            } else {
              res.send({
                status: 1,
                msg: "Health Tip Updated Successfully",
                data: []
              });
            }
          }
        });
      }
    } catch {
      res.send({ status: 0, msg: "Validation Error", data: [] });
    }
  });

router.post("/deleteHealthTip", (req, res) => {
    try {
      var validationStatus = true;
      var Errors = [];
      var responseJson = {};

      if (req.body) {
        if (
          typeof req.body.healthTipId == null ||
          req.body.healthTipId == undefined ||
          req.body.healthTipId == ""
        ) {
          Errors.push("healthTipId is empty or incorrect");
          validationStatus = false;
        } else {
          req.body.healthTipId;
        }
        if (
          typeof req.body.updatedBy == null ||
          req.body.updatedBy == undefined ||
          req.body.updatedBy == ""
        ) {
          Errors.push("updatedBy is empty or incorrect");
          validationStatus = false;
        } else {
          req.body.updatedBy;
        }
      } else {
        Errors.push("Request Body is empty");
        validationStatus = false;
      }
      if (!validationStatus) {
        responseJson.status = 0;
        responseJson.message = "Invalida Request Body";
        responseJson.payload = Errors;
        return res.send(responseJson);
      } else {
        var queryParams = req.body;

        var query =
          "UPDATE `mas_to_healthtip` SET `active_flag` = '0',`modified_by`='" +
          queryParams.updatedBy +
          "',`modified_on`=NOW()  WHERE mas_to_healthtip.`id`='" +
          queryParams.healthTipId +
          "';";
        db.query(query, (err, response) => {
          if (err) {
            console.log(err);
            console.log(errorCode);
            res.send(errorCode.errorCodeResponse(err.errno));
          } else {
            console.log(response);
            if (response.affectedRows == 0) {
              res.send({ status: 0, msg: "Health Tip is Not Deleted", data: [] });
            } else {
              res.send({
                status: 1,
                msg: "Health Tip Deleted Successfully",
                data: []
              });
            }
          }
        });
      }
    } catch {
      res.send({ status: 0, msg: "Validation Error", data: [] });
    }
  });

router.post("/getHealthTipList",(req,res)=>{
    var query = "SELECT id AS healthTipId,to_healthtip AS healthTipName FROM `mas_to_healthtip` WHERE active_flag = 1";
    db.query(query,(err,response)=>{
        if(err){
            console.log(err);
            res.send(errorCode.errorCodeResponse(err.errno));
        }else{
            if(response.length > 0){

                res.send({
                    status: 1,
                    msg: "Success",
                    data: response
                  });
            }else{
                res.send({
                    status: 0,
                    msg: "Data is Empty",
                    data: response
                  });

            }
        }

    })
})

  return router;
};
