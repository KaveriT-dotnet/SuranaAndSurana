module.exports = function(router, db, errorCode) {

//Insert Health Tip Content

  router.post("/insertHealthTipContent", (req, res) => {
    try {
      var validationStatus = true;
      var Errors = [];
      var responseJson = {};

      if (req.body) {
        if (
          typeof req.body.healthTipContent == null ||
          req.body.healthTipContent == undefined ||
          req.body.healthTipContent == ""
        ) {
          Errors.push("healthTipContent is empty or incorrect");
          validationStatus = false;
        } else {
          req.body.healthTipContent;
        }
        if (
          typeof req.body.healthTipId == null ||
          req.body.healthTipId == undefined ||
          req.body.healthTipId == ""
        ) {
          Errors.push("healthTipId is empty or incorrect");
          validationStatus = false;
        } else {
          req.body.healthTipId;
        }
        if (
          typeof req.body.createdBy == null ||
          req.body.createdBy == undefined ||
          req.body.createdBy == ""
        ) {
          Errors.push("createdBy is empty or incorrect");
          validationStatus = false;
        } else {
          req.body.createdBy;
        }
      } else {
        Errors.push("Request Body is empty");
        validationStatus = false;
      }
      if (!validationStatus) {
        responseJson.status = 0;
        responseJson.message = "Invalida Request Body";
        responseJson.payload = Errors;
        return res.send(responseJson);
      } else {
        var queryParams = req.body;

          var query = "INSERT INTO `mas_health_tip`(`health_tip`, `to_healthtip_id`, `created_by`, `created_on`) VALUES ('" +
          queryParams.healthTipContent +
          "','" +
          queryParams.healthTipId +
          "','" +
          queryParams.createdBy +
          "',NOW())"
        db.query(query, (err, response) => {
          if (err) {
            console.log(err);
            res.send(errorCode.errorCodeResponse(err.errno));
          } else {
            if (response.affectedRows == 0) {
              res.send({ status: 0, msg: "Not Inserted", data: [] });
            }else{
              res.send({ status: 1, msg: "Success", data: [] });
            }
          }
        });
      }
    } catch {
      res.send({ status: 0, msg: "Internal Server Error", data: [] });
    }
  });

//Update Api for healthtip Content

  router.post("/updateHealthTipContent", (req, res) => {
    try {
      var validationStatus = true;
      var Errors = [];
      var responseJson = {};

      if (req.body) {
        if (
          typeof req.body.healthTipContent == null ||
          req.body.healthTipContent == undefined ||
          req.body.healthTipContent == ""
        ) {
          Errors.push("healthTipContent is empty or incorrect");
          validationStatus = false;
        } else {
          req.body.healthTipContent;
        }
        if (
          typeof req.body.healthTipId == null ||
          req.body.healthTipId == undefined ||
          req.body.healthTipId == ""
        ) {
          Errors.push("healthTipId is empty or incorrect");
          validationStatus = false;
        } else {
          req.body.healthTipId;
        }
        if (
          typeof req.body.updatedBy == null ||
          req.body.updatedBy == undefined ||
          req.body.updatedBy == ""
        ) {
          Errors.push("updatedBy is empty or incorrect");
          validationStatus = false;
        } else {
          req.body.updatedBy;
        }
        if (
          typeof req.body.healthTipContentId == null ||
          req.body.healthTipContentId == undefined ||
          req.body.healthTipContentId == ""
        ) {
          Errors.push("healthTipContentId is empty or incorrect");
          validationStatus = false;
        } else {
          req.body.healthTipContentId;
        }
      } else {
        Errors.push("Request Body is empty");
        validationStatus = false;
      }
      if (!validationStatus) {
        responseJson.status = 0;
        responseJson.message = "Invalida Request Body";
        responseJson.payload = Errors;
        return res.send(responseJson);
      } else {
        var queryParams = req.body;

          var query = "UPDATE `mas_health_tip` SET `health_tip`='"+queryParams.healthTipContent+"',`to_healthtip_id`='"+queryParams.healthTipId+"',`modified_by`='"+queryParams.updatedBy+"',`modified_on`=NOW() WHERE `mas_health_tip`.`id`='"+queryParams.healthTipContentId+"';";
        db.query(query, (err, response) => {
          if (err) {
            console.log(err);
            console.log(errorCode);
            res.send(errorCode.errorCodeResponse(err.errno));
          } else {
            console.log(response);
            if (response.affectedRows == 0) {
              res.send({ status: 0, msg: "Health Tip Content Not Updated", data: [] });
            } else {
              res.send({
                status: 1,
                msg: "Health Tip Content Updated Successfully",
                data: []
              });
            }
          }
        });
      }
    } catch {
      res.send({ status: 0, msg: "Validation Error", data: [] });
    }
  });

// Delete Api for healthtip content

router.post("/deleteHealthTipContent", (req, res) => {
    try {
      var validationStatus = true;
      var Errors = [];
      var responseJson = {};

      if (req.body) {
        if (
          typeof req.body.healthTipId == null ||
          req.body.healthTipId == undefined ||
          req.body.healthTipId == ""
        ) {
          Errors.push("healthTipId is empty or incorrect");
          validationStatus = false;
        } else {
          req.body.healthTipId;
        }
        if (
          typeof req.body.updatedBy == null ||
          req.body.updatedBy == undefined ||
          req.body.updatedBy == ""
        ) {
          Errors.push("updatedBy is empty or incorrect");
          validationStatus = false;
        } else {
          req.body.updatedBy;
        }
      } else {
        Errors.push("Request Body is empty");
        validationStatus = false;
      }
      if (!validationStatus) {
        responseJson.status = 0;
        responseJson.message = "Invalida Request Body";
        responseJson.payload = Errors;
        return res.send(responseJson);
      } else {
        var queryParams = req.body;

        var query = "UPDATE `mas_health_tip` SET `active_flag`='0',`modified_by`='"+queryParams.updatedBy+"',`modified_on`=NOW() WHERE `mas_health_tip`.`id`='"+queryParams.healthTipContentId+"' AND `to_healthtip_id`='"+queryParams.healthTipId+"';";
        db.query(query, (err, response) => {
          if (err) {
            console.log(err);
            console.log(errorCode);
            res.send(errorCode.errorCodeResponse(err.errno));
          } else {
            console.log(response);
            if (response.affectedRows == 0) {
              res.send({ status: 0, msg: "Health Tip Content is Not Deleted", data: [] });
            } else {
              res.send({
                status: 1,
                msg: "Health Tip Content is Deleted Successfully",
                data: []
              });
            }
          }
        });
      }
    } catch {
      res.send({ status: 0, msg: "Validation Error", data: [] });
    }
  });

// Get API of healthtipContent

router.post("/getHealthTipListContent",(req,res)=>{
    var query = "SELECT mas_to_healthtip.id AS healthTipId,to_healthtip AS healthTipName FROM `mas_to_healthtip` WHERE mas_to_healthtip.active_flag = 1 ";
    db.query(query,(err,response)=>{
        if(err){
            console.log(err);
            res.send(errorCode.errorCodeResponse(err.errno));
        }else{
            if(response.length > 0){

              response.forEach(async (item,i) => {
                
                response[i].tipsContent = await healthTipContentData(response[i].healthTipId);

                if(i == response.length -1){
                res.send({
                    status: 1,
                    msg: "Success",
                    data: response
                  });
                  }

              });

            }else{
                res.send({
                    status: 0,
                    msg: "Data is Empty",
                    data: response
                  });

            }
        }

    })
})


//Functions of the above APIs are reutn below

healthTipContentData =(healthTipId)=>{
  return new Promise((resolve,reject) =>{
    var query = "SELECT id AS healthTipContentId,health_tip AS healthTipContent FROM `mas_health_tip` WHERE mas_health_tip.to_healthtip_id = '"+healthTipId+"' AND mas_health_tip.active_flag = 1";
    db.query(query,(err,response)=>{
      if(err){
        reject(err);
      }else{
        resolve(response);
      }
    })
  })

}



  return router;
};
