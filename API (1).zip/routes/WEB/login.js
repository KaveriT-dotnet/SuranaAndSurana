module.exports = function(router,db,async){

router.post("/login",function(req,res){
	try{
		
	var query = "";
	}catch{
		
		
	}
})

return router;
}