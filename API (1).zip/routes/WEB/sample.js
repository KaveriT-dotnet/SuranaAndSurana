module.exports = function(router,db){

router.post("/vneuApproval",function(req, res) {

try{
  var query = "SELECT * FROM SOMETABLENAME";
  db.query(query,function(err,response){ 
    if(err){
      console.log(err);
    }else{
      res.send({ status: 0, msg: 'Success', data: response });
    }
  })

} catch (err) {
    console.log("CatchError", err.message)
    console.log("CatchError", err)

    res.send({ status: 1, msg: 'validation Error', data: [] })
  }

});
return router;


}