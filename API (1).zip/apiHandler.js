const sample = require("./routes/WEB/sample");
const login = require("./routes/WEB/login");
//const moduleMaster = require("./routes/WEB/moduleMaster"); 
const doctor_speciality =  require("./routes/WEB/SUPERADMIN/SPECIALITY/doctor_speciality");

 
//Web Admin API LIST - Super Admin
const groupMaster =  require("./routes/WEB/SUPERADMIN/GROUP/groupmaster");
const userType =  require("./routes/WEB/SUPERADMIN/USER/userType");
const userMaster =  require("./routes/WEB/SUPERADMIN/USER/userMaster");
const groupPermission =  require("./routes/WEB/SUPERADMIN/GROUP/groupPermission");
const commission = require('./routes/WEB/SUPERADMIN/COMMISSION/mas_commission');
const holiday = require('./routes/WEB/SUPERADMIN/HOLIDAY/mas_holiday_master');
const mediaUpload = require('./routes/WEB/SUPERADMIN/MEDIA/mas_media_upload');
const moduleMaster = require('./routes/WEB/SUPERADMIN/MODULE/mas_module_master');
const subModule = require('./routes/WEB/SUPERADMIN/MODULE/mas_sub_module_master');
const notification = require('./routes/WEB/SUPERADMIN/NOTIFICATION/mas_notification_rights');
const screenMaster = require('./routes/WEB/SUPERADMIN/SCREEN/mas_screen_master');
const specialityMaster = require('./routes/WEB/SUPERADMIN/SPECIALITY/mas_doctor_speciality');
const trainerMaster = require('./routes/WEB/SUPERADMIN/TRAINER/mas_trainer');
const trainingMode = require('./routes/WEB/SUPERADMIN/TRAINER/mas_training_mode');
const userPermission = require('./routes/WEB/SUPERADMIN/USER/mas_user_permission');
const vendorMaster  = require('./routes/WEB/SUPERADMIN/VENDOR/mas_vendor_master')


// web - super admin
const healthTip = require('./routes/WEB/SUPERADMIN/HEALTHTIP/healthtip');
const healthTipContent = require('./routes/WEB/SUPERADMIN/HEALTHTIP/healthtipContent');
const trainingCategory = require('./routes/WEB/SUPERADMIN/TRAINER/trainingcategory');
const training = require('./routes/WEB/SUPERADMIN/TRAINER/training');
const trainerCategory = require('./routes/WEB/SUPERADMIN/TRAINER/trainerCategory');




let apiHandler = {  
	init: function(app,router,db,nodemailer,Mustache,fs,ses,async,dateFormat,errorData)
	{   
        let version = "/api/v1/";            
        app.use(version,sample(router,db)); 
		app.use(version,login(router,db));  
		app.use(version,groupMaster(router,db));
		app.use(version,userType(router,db));   
		app.use(version,userMaster(router,db));     
		app.use(version,groupPermission(router,db));    
		//app.use(version,moduleMaster(router,db));
		app.use(version,healthTip(router,db,errorData));  
		app.use(version,healthTipContent(router,db,errorData));
		app.use(version,trainingCategory(router,db,errorData));  
		app.use(version,training(router,db,errorData));  
		app.use(version,trainerCategory(router,db,errorData));
		app.use(version,commission(router,db,errorData));
		app.use(version,holiday(router,db,errorData));
		app.use(version,mediaUpload(router,db,errorData)); 
		app.use(version,moduleMaster(router,db,errorData));  
		app.use(version,subModule(router,db,errorData));  
		app.use(version,notification(router,db,errorData));
		app.use(version,screenMaster(router,db,errorData));
		app.use(version,specialityMaster(router,db,errorData)); 
		app.use(version,trainerMaster(router,db,errorData));
		app.use(version,trainingMode(router,db,errorData)); 
		app.use(version,userPermission(router,db,errorData));
		app.use(version,vendorMaster(router,db,errorData)); 



       }    
};
module.exports = apiHandler;  
